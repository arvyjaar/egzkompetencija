<?php

return [
    'site_title' => 'Kompetencijos vertinimas',
];
