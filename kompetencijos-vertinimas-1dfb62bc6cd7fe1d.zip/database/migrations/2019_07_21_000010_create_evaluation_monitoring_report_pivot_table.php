<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEvaluationMonitoringReportPivotTable extends Migration
{
    public function up()
    {
        Schema::create('evaluation_monitoring_report', function (Blueprint $table) {
            $table->unsignedInteger('evaluation_id');
            $table->foreign('evaluation_id', 'evaluation_id_fk_173133')->references('id')->on('evaluations');
            $table->unsignedInteger('monitoring_report_id');
            $table->foreign('monitoring_report_id', 'monitoring_report_id_fk_173133')->references('id')->on('monitoring_reports');
        });
    }
}
