<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Create1563128968476CriterionEvaluationPivotTable extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('criterion_evaluation')) {
            Schema::create('criterion_evaluation', function (Blueprint $table) {
                $table->unsignedInteger('evaluation_id');
                $table->foreign('evaluation_id', 'evaluation_id_fk_173134')->references('id')->on('evaluations');
                $table->unsignedInteger('criterion_id');
                $table->foreign('criterion_id', 'criterion_id_fk_173134')->references('id')->on('criteria');
            });
        }
    }

    public function down()
    {
        Schema::dropIfExists('criterion_evaluation');
    }
}
