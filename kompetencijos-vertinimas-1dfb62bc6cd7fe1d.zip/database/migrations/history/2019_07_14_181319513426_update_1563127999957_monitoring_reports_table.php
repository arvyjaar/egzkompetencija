<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Update1563127999957MonitoringReportsTable extends Migration
{
    public function up()
    {
        Schema::table('monitoring_reports', function (Blueprint $table) {
            $table->longText('technical_notes')->nullable();
            $table->longText('observer_notes')->nullable();
            $table->longText('examiner_notes')->nullable();
            $table->datetime('examiner_reviewed')->nullable();
            $table->longText('evpis_notes')->nullable();
        });
    }

    public function down()
    {
        Schema::table('monitoring_reports', function (Blueprint $table) {
        });
    }
}
