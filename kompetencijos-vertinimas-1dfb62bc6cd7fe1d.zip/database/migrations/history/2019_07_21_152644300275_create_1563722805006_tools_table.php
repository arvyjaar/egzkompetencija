<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Create1563722805006ToolsTable extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('tools')) {
            Schema::create('tools', function (Blueprint $table) {
                $table->increments('id');
                $table->string('title');
                $table->string('model')->nullable();
                $table->string('condition');
                $table->longText('note')->nullable();
                $table->string('branch');
                $table->timestamps();
                $table->softDeletes();
            });
        }
    }

    public function down()
    {
        Schema::dropIfExists('tools');
    }
}
