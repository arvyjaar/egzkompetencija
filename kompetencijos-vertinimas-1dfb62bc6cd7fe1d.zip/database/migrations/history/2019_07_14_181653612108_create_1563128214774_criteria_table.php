<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Create1563128214774CriteriaTable extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('criteria')) {
            Schema::create('criteria', function (Blueprint $table) {
                $table->increments('id');
                $table->string('title');
                $table->timestamps();
                $table->softDeletes();
            });
        }
    }

    public function down()
    {
        Schema::dropIfExists('criteria');
    }
}
