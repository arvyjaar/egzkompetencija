<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Create1563126318167MonitoringReportsTable extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('monitoring_reports')) {
            Schema::create('monitoring_reports', function (Blueprint $table) {
                $table->increments('id');
                $table->string('observer');
                $table->unsignedInteger('user_id');
                $table->foreign('user_id', 'user_fk_173104')->references('id')->on('users');
                $table->string('branch');
                $table->datetime('exam_date');
                $table->string('category');
                $table->date('observing_date');
                $table->string('observing_type');
                $table->timestamps();
                $table->softDeletes();
            });
        }
    }

    public function down()
    {
        Schema::dropIfExists('monitoring_reports');
    }
}
