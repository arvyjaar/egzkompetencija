<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Create1563128968487EvaluationPointPivotTable extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('evaluation_point')) {
            Schema::create('evaluation_point', function (Blueprint $table) {
                $table->unsignedInteger('evaluation_id');
                $table->foreign('evaluation_id', 'evaluation_id_fk_173135')->references('id')->on('evaluations');
                $table->unsignedInteger('point_id');
                $table->foreign('point_id', 'point_id_fk_173135')->references('id')->on('points');
            });
        }
    }

    public function down()
    {
        Schema::dropIfExists('evaluation_point');
    }
}
