<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMonitoringReportsTable extends Migration
{
    public function up()
    {
        Schema::create('monitoring_reports', function (Blueprint $table) {
            $table->increments('id');
            $table->string('observer');
            $table->string('branch');
            $table->datetime('exam_date');
            $table->string('category');
            $table->date('observing_date');
            $table->string('observing_type');
            $table->longText('technical_notes')->nullable();
            $table->longText('observer_notes')->nullable();
            $table->longText('examiner_notes')->nullable();
            $table->datetime('examiner_reviewed')->nullable();
            $table->longText('evpis_notes')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
}
