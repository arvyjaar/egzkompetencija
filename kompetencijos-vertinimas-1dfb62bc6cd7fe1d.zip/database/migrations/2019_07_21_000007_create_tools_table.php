<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateToolsTable extends Migration
{
    public function up()
    {
        Schema::create('tools', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title');
            $table->string('model')->nullable();
            $table->string('condition');
            $table->longText('note')->nullable();
            $table->string('branch');
            $table->timestamps();
            $table->softDeletes();
        });
    }
}
