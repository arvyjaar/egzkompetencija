<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToMonitoringReportsTable extends Migration
{
    public function up()
    {
        Schema::table('monitoring_reports', function (Blueprint $table) {
            $table->unsignedInteger('user_id');
            $table->foreign('user_id', 'user_fk_173104')->references('id')->on('users');
        });
    }
}
